import express from 'express'
import { engine } from 'express-handlebars'
import { receiveData, showForm, showHome } from './controllers/HomeController.js'


const app = express()

app.engine('handlebars', engine())
app.set('view engine', 'handlebars')
app.set('views', './src/views')

app.use(express.urlencoded({extended: true}))

app.get('/', showHome)
app.get('/form', showForm)
app.post('/form', receiveData)

app.listen(3000, ()=> console.log('Servidor listo en http://localhost:3000'))
