import { pool } from "../db.js";

export async function getAllUsers() {
  const [rows] = await pool.query("SELECT * FROM alumnos");
  return rows;
}

export async function createUser(nombre, apellido) {
  await pool.query("INSERT INTO alumnos (nombre, apellido) VALUES (?, ?)", [nombre, apellido]);
}
