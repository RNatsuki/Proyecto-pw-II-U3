import { createUser, getAllUsers } from "../models/userModel.js";

export async function showHome(req, res) {
  const nombres = await getAllUsers();
  return res.render("home", { layout: false, nombres });
}

export function showForm(req, res) {
  return res.render("form", { layout: false });
}

export async function receiveData(req, res) {
  const nombre = req.body.nombre;
  const apellido = req.body.apellido;

  await createUser(nombre, apellido);
  return res.redirect("/");
}
