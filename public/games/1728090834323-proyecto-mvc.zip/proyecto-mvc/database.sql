CREATE DATABASE alumnos;
USE alumnos;


CREATE TABLE alumnos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100)
);


INSERT INTO alumnos (nombre, apellido) VALUES
('Rodrigo', 'Ibarra'),
('Adrian', 'Madrigal'),
('Mauricio', 'Villegas')
