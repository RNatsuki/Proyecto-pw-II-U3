

export const renderIndex = (req, res) => {
    return res.render('index', {title: 'Home'});
}
