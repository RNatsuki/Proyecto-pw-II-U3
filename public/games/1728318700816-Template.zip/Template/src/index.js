import express from "express";
import { engine } from "express-handlebars";
import { renderIndex } from "./controllers/HomeController.js";
import livereload from "livereload";
import connectLivereload from "connect-livereload";

const liveReloadServer = livereload.createServer();
liveReloadServer.watch(process.cwd() + "/public");


liveReloadServer.server.once("connection", () => {
  setTimeout(() => {
    liveReloadServer.refresh("/");
  }, 100);
});

const app = express();

app.use(connectLivereload());

// Set handlebars as the template engine
app.engine("handlebars", engine());
app.set("view engine", "handlebars");
app.set("views", "./src/views");

// Set the public folder as a static folder
app.use("/public", express.static("public"));

// Routes
app.get("/", renderIndex);

app.listen(3000, () => {
  console.log("Server is running on http://localhost:3000");
});
